﻿namespace Mine.Models
{
    /// <summary>
    /// List of items to show in the Menu
    /// </summary>
    public enum MenuItemEnum
    {
        Browse,
        About
    }
}